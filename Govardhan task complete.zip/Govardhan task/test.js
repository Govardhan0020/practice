
const arr =[
    {name:"arjun",age:28,gender:"male",place:"HYD",pincode:500062,phonenumber:887766554433,email_id:"arjun123@gmail.com", workplace:"Resourceone IT Solutions" ,roll:"sr.Buninness analyst", family: "mather, father , wife , no children " ,com1:"nice worker " ,com2:"hard working pweson " },
    {name:"rama",age:25,gender:"female",place:"HYD",pincode:500061,phonenumber:9989764235,email_id:"rama45@gmail.com",workplace:"Resourceone IT Solutions" ,roll:"jr.Buninness analyst", family: "mather, father , wife , 2 children ", com1:"nice worker " ,com2:"hard working pweson "}, 
   {name:"sai",age:23,gender:"male",place:"HYD",pincode:500062,phonenumber:9553646390,email_id:"sai68@gmail.com",workplace:"Resourceone IT Solutions" ,roll:"sr.Buninness analist", family: "mather, father , wife , two children " ,com1:"nice worker " ,com2:"hard working pweson "},
    {name:"gopal",age:22,gender:"male",place:"HYD",pincode:500068,phonenumber:8899144144,email_id:"gopal76@gmail.com",workplace:"Resourceone IT Solutions" ,roll:"jr.developer", family: "mather, father  ", com1:"nice worker " ,com2:"hard working pweson "},
    {name:"krishna",age:27,gender:"male",place:"HYD",pincode:500065,phonenumber:9052063048,email_id:"Krishna24@gmail.com",workplace:"Resourceone IT Solutions" ,roll:"sr.developer", family: "mather, father , wife , 1 children ", com1:"nice worker " ,com2:"hard working pweson "}
      ]
var table = document.getElementById("tableid");

function showtable(){
var head='',body='';
head="<table> <tr><th> Name</th> <th>Age</th> <th>Place</th> <th>Pincode</th> </tr></table>"
arr.forEach((data) =>
body+= '<tr>'+
'<td>'+ data.name +"</td>"+
'<td>'+data.age +'</td>' +
'<td>' +data.place +'</td> '+
'<td>' +data.pincode +'</td> <tr>'
)
table.innerHTML=head+body;
}


var locarr=[];

   table.addEventListener('click', function (item) {
 
var row = item.path[1];
var fname = row.cells[0].innerHTML;
     
// alert(setname);

   var getname = fname;
 var arrindex = arr.findIndex((val) => val.name == getname);
//   console.log(arrindex);   
var setname = arr[arrindex].name;
var setage = arr[arrindex].age;
var setgender = arr[arrindex].gender;
var setphonenumber = arr[arrindex].phonenumber;
var setemail = arr[arrindex].email_id;
var setplace = arr[arrindex].place;
var setpincode = arr[arrindex].pincode;
var setworkplace = arr[arrindex].workplace;
var setroll = arr[arrindex].roll;
var setfamily = arr[arrindex].family;
var setcom1 =arr[arrindex].com1;
var setcom2 =arr[arrindex].com2;

var locobj ={Name:setname,Age:setage,Place:setplace,Gender:setgender,Phonenumber:setphonenumber,EmailId:setemail,
             Pincode:setpincode,Workplace:setworkplace,Roll:setroll,Family:setfamily,Com1:setcom1,Com2:setcom2};
locarr.push(locobj);

localStorage.setItem("userdata",JSON.stringify(locarr));

window,location.href="full.html";

       }) ;
  

 




// function newpage(namedata){

//   var getname = namedata;
// var arrindex = arr.findIndex((val) => val.name == getname);
     
// var setname = arr[arrindex].name;
// var setage = arr[arrindex].age;
// var setgender = arr[arrindex].gender;
// var setphonenumber = arr[arrindex].phonenumber;
// var setemail = arr[arrindex].email_id;
// var setplace = arr[arrindex].place;
// var setpincode = arr[arrindex].pincode;
// var setworkplace = arr[arrindex].workplace;
// var setroll = arr[arrindex].roll;
// var setfamily = arr[arrindex].family;

// var locobj ={Name:setname,Age:setage,Place:setplace,Gender:setgender,Phonenumber:setphonenumber,EmailId:setemail,
//              Pincode:setpincode,Workplace:setworkplace,Roll:setroll,Family:setfamily};
// locarr.push(locobj);

// localStorage.setItem("userdata",JSON.stringify(locarr));

// window,location.href="full.html";

//        }
  


//   function displaydata() {

//    var outdata = localStorage.getItem('userdata');
//   var finaldata = JSON.parse(outdata);
//     console,log(finaldata);
//   document.getElementById("user").innerHTML = finaldata[0].Age;

// //  }

