
 var clientdata,p_email,s_email, name,lastname,phonenumber,priemail,count,projectname,projectstatus,secondemail,table,tableout;
 var dataarray= [];
count=0;
dataarray =[
// { name:'Name',lastname:'LastName',phonenumber:'phonenumber',p_email:'Primeary email',s_email:'secondary email',projectname:'projectname',projectstatus:'projectstatus;'},
{id:count+=1,name:'sree',lastname:"sure", phonenumber:9076843256,p_email:'sree@gmail.com',s_email:'sree2@gmail.com',projectname:'table',projectstatus:'running'},
{id:count+=1,name:'rama',lastname:"dagha", phonenumber:9876548767,p_email:'rama45@gmail.com',s_email:'ramma2878@gmail.com',projectname:'bookmyshow',projectstatus:'completed'},
{id:count+=1,name:'sitha',lastname:"kalyani", phonenumber:7799531618,p_email:'sithass56@gmail.com',s_email:'sitha431@gmail.com',projectname:'flipkart',projectstatus:'completed'},
{id:count+=1,name:'krishna',lastname:"rao", phonenumber:905203048,p_email:'krish004@gmail.com',s_email:'krishna456@gmail.com',projectname:'amazon',projectstatus:'running'},
{id:count+=1,name:'shiva',lastname:"rao", phonenumber:9989764320,p_email:'siva48@gmail.com',s_email:'shiva654@gmail.com',projectname:'ecommerece',projectstatus:'completed'}

];

var tabledata =document.getElementById('tableid')


  function rowadd(){
  event.preventDefault();

	  name =document.getElementById('name').value;
 	  lastname=document.getElementById('lastname').value;
 	 phonenumber =document.getElementById('phonenumber').value;
 	 priemail =document.getElementById('primardmail').value;
 	 secondemail = document.getElementById('secmail').value;
 	 projectname =document.getElementById('projectname').value;
 	 projectstatus =document.getElementById('status').value; 

 clientdata ={
	Name:name,
	LastName:lastname,
	Phone:phonenumber,
	P_email:priemail,
	s_email:secondemail,
	P_name:projectname,
	P_status:projectstatus,
}
if(dataarray.find(val => {return val.p_email == priemail} )){
	alert("the primary email is already exist");
} else if (dataarray.find(val => {return val.s_email == secondemail})){
	alert("the secondary email is alredy existed ");
} else { 
dataarray.push(clientdata);
alert("data inserted successfully ");

}
console.log(dataarray);
createtable();

 }
var row=0;
 function createtable() { 

//   tableout ="<table   border='2px solid black '  >";
// for(var i=0;i<dataarray.length;i++){
// 	tableout+="<tr id= " +i+1+" >";
//    tableout+="<td>"+dataarray[i].id+'</td>';
// 	tableout+='<td>'+dataarray[i].name+'</td>';
// 		tableout+='<td>'+dataarray[i].lastname+'</td>';
// 			tableout+='<td>'+dataarray[i].phonenumber+'</td>';
// 				tableout+='<td>'+dataarray[i].p_email+'</td>';
// 					tableout+='<td>'+dataarray[i].s_email+'</td>';
// 						tableout+='<td>'+dataarray[i].projectname+'</td>';
// 							tableout+='<td>'+dataarray[i].projectstatus+'</td>';
//               tableout+='<td>'+'<div id="checkbox"><input type="checkbox"  /> </div> '+'</td>';
//     tableout+='<td>'+'<i onclick="deleterow()" class="fa fa-trash-o"></i> '+'</td>';
// }
//  tabledata.innerHTML +=tableout;
     var tbody = document.getElementById("tbody");
         // tbody.innerHTML = "";
         for (var x of dataarray){
         	let tr = document.createElement("tr");

         	   tr.innerHTML = `
         	
         	   <td>${x.id}</td>
         	   <td>${x.name}</td>
         	   <td>${x.lastname}</td>
         	   <td>${x.phonenumber}</td>
         	   <td>${p_email}</td>
         	   <td>${s_email}</td>
         	   <td>${x.projectname}</td>
         	   <td>${x.projectstatus}</td>
        
</tr> 
         	   `
                tbody.appendChild(tr);
         }

}

 

function deleterow()  {

let checkbox =document.getElementById('checkbox');
let box =document.getElementById('+ i+1 +');
if( box.checked == true){
	checkbox.style.display="none";
}

// 	name =prompt("enter the name")
// let delele=	dataarray.findIndex(arobj => arobj.name === name )
// let pos =Number(delele);
//   let remele = dataarray.splice(pos,1);
// // dataarray.splice(name,lastname,phonenumber,p_email,s_email,projectname,projectstatus);
   tabledata.innerHTML = tableout;
// // createtable();
 

console.log(pos);
console.log(remele);
}


function searchdata() {
  var input, filter, table, tr, td, i;
  input = document.getElementById("myInput");
  filter = input.value.toUpperCase();
  table = document.getElementById("tableid");
  tr = table.getElementsByTagName("tr");
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[1];
    if (td) {
      if (td.innerHTML.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    }       
  }
}






