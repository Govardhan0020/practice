
	function kup() {
			var x= document.getElementById('inp').value

		document.getElementById("out").innerHTML=x;
	}
