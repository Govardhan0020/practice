function clrgreen() {
	document.getElementById('imgmain').src="https://rukminim1.flixcart.com/image/416/416/l2jcccw0/mobile/h/x/3/-original-imagduwqakhhkrse.jpeg?q=70";
   document.getElementById("mobname").innerHTML="Carbon Black";
}


function clrmidnight(){
	document.getElementById("imgmain").src="https://rukminim1.flixcart.com/image/416/416/l4d2ljk0/mobile/z/i/s/-original-imagf9wt7v5pugmy.jpeg?q=70";
document.getElementById("mobname").innerHTML="Mid night Black";
}

function blurflame(){
	document.getElementById("imgmain").src="https://rukminim1.flixcart.com/image/416/416/l4d2ljk0/mobile/x/d/z/-original-imagf9wt5emzsjqz.jpeg?q=70";
document.getElementById("mobname").innerHTML="Blue Flame";
}

function small() {
	document.getElementById("shirtpice").innerHTML="₹ 399";
}


function medium() {
	document.getElementById("shirtpice").innerHTML="₹ 499";
}


function large() {
	document.getElementById("shirtpice").innerHTML="₹ 699";
}

function navyblue() {
	document.getElementById("imgshirt").src="https://rukminim1.flixcart.com/image/800/960/xif0q/shirt/z/u/n/40-bfnbsht02ab-being-fab-original-imafwyfypqkwwrez-bb.jpeg?q=50";
  document.getElementById("shirtclr").innerHTML=" Navy Blue";
}


function red() {
	document.getElementById("imgshirt").src=" https://rukminim1.flixcart.com/image/800/960/k65d18w0/shirt/s/w/x/50-bfredsht02ab-being-fab-original-imaecvnx9swvsvp5.jpeg?q=50";
  document.getElementById("shirtclr").innerHTML=" Red";

}


function white() {
	document.getElementById("imgshirt").src=" https://rukminim1.flixcart.com/image/800/960/kfoapow0-0/shirt/f/u/k/38-bfbbpnksht02ab-being-fab-original-imafw2ggfhks2fya.jpeg?q=50";
  document.getElementById("shirtclr").innerHTML="White ";

}


function maroon() {
	document.getElementById("imgshirt").src=" https://rukminim1.flixcart.com/image/800/960/xif0q/shirt/m/3/k/50-bfmrnsht02ab-being-fab-original-imaeapugymrzxaeg-bb.jpeg?q=50";
  document.getElementById("shirtclr").innerHTML=" Maroon";

}


function  royalblue() {
	document.getElementById("imgshirt").src=" https://rukminim1.flixcart.com/image/800/960/k65d18w0/shirt/p/4/t/48-bfrybluesht02ab-being-fab-original-imaecvnxndp3zbdn.jpeg?q=50";
  document.getElementById("shirtclr").innerHTML=" Royal Blue";

}

function yellow() {
	document.getElementById("imgshirt").src="https://rukminim1.flixcart.com/image/800/960/kdnf98w0hlty2aw-0/shirt/6/e/4/38-bfyelwsht02ab-being-fab-original-imafuhzg2ctjhbrn.jpeg?q=50";
    document.getElementById("shirtclr").innerHTML=" Yellow";
}

function black() {
	document.getElementById("imgshirt").src="https://rukminim1.flixcart.com/image/800/960/k65d18w0/shirt/f/s/m/50-bfblksht02ab-being-fab-original-imae7darhnqbz4rq.jpeg?q=50";
    document.getElementById("shirtclr").innerHTML="Black";
}