const data =[
{
	"name":"sita",
	"age":24
},
{
	"naem":"rama",
	"age":25
}]

export default data;