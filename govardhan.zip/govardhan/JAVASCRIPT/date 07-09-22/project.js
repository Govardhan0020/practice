
const products =[
{
	name:"watch",
    price:2549,
    discription:"The item nice to buy, it has  ",
    img:"C:\Users\DAY\Desktop\govardhan\JAVASCRIPT\date 07-09-22\img2.jpg"
},
{
	name:"phone",
    price:2549,
    discription:"The item nice to buy, it has  ",
    img:""
},
{
	name:"laptop",
    price:2549,
    discription:"The item nice to buy, it has  ",
    img:""
},
{
	name:"phone",
    price:2549,
    discription:"The item nice to buy, it has  ",
    img:""
},
{
	name:"phone",
    price:2549,
    discription:"The item nice to buy, it has  ",
    img:""
},
{
	name:"phone",
    price:2549,
    discription:"The item nice to buy, it has  ",
    img:""
},{
	name:"watch",
    price:2549,
    discription:"The item nice to buy, it has  ",
    img:""
},
]

var result='';
products.forEach((item) =>   
 result += '<div class="items" >' +
            '<img src="+ item.img + " >'+
           '<h4 class="prodname" >'+ item.name + '</h4>' +
               '<p class="prodprice "> ' +item.price +'</p>' +
               '<p class="dis"> '+item.discription+'</p>' +
               '</div>'
	 
	 )
document.getElementById('product').innerHTML =result;


