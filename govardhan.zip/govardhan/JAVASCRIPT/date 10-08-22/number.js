function connumber() {
	let num =prompt("enter the numeric string to convert into number");
	let res=Number(num);
	document.getElementById('id1').innerHTML='your entered Number is : '+ num +" <br> type is : "+ typeof num;
	document.getElementById('id2').innerHTML="Number is : " + res + "<br> type of : " + typeof res;
}

function constring() {
	let str = Number(prompt("enter the number to convert into string "));
	let res= str.toString();
	document.getElementById("id3").innerHTML="your entered Numeric string is :"+str + "<br> type is :"+typeof str;
	document.getElementById('id4').innerHTML="string is :"+res +"<br> type is :"+typeof res;
}

function coninteger() {
let num =prompt("enter the numeric string to convert into number");
	let res=parseInt(num);
	document.getElementById('id5').innerHTML='your entered Number is : '+ num +" <br> type is : "+ typeof num;
	document.getElementById('id6').innerHTML="Number is : " + res + "<br> type of : " + typeof res;
}


function confloat() {
let num =prompt("enter the numeric string to convert into number");
	let res=parseFloat(num);
	document.getElementById('id7').innerHTML=' your entered Number is : '+ num +" <br> type is : "+ typeof num;
	document.getElementById('id8').innerHTML="Number is : " + res + "<br> type of : " + typeof res;
}

function expo() {
	let data =Number( prompt( "enter the  number to convert into exponential form "));
    let val = prompt("enter no. of values of exponential needed ");
  document.getElementById("id9").innerHTML= "exponential is :"+data.toExponential(val);
}

function fix() {
	let data =Number( prompt( "enter the  number to show the fixed "));
    let val = prompt("enter no. of values to fixed  ");
  document.getElementById("id10").innerHTML= "fixed is :"+data.toFixed(val);
}


function precision() {
	let data =Number( prompt( "enter the  number to show the precision  "));
    let val = prompt("enter no. of values to precision ");
  document.getElementById("id11").innerHTML= "precision is :"+data.toPrecision(val);
}

function value() {
  	let data =Number( prompt( "enter the  number to find value   "));
    document.getElementById("id11").innerHTML= "value is :"+data.valueOf();

 }


function type() {
	let data = prompt("enter the data to find its type");
	document.getElementById("id12").innerHTML="Type is : "+typeof data;
}



// var a = prompt("Enter a value");
// var z = a;
// var reverse = 0;
// while(z > 0)
// {
//     var digit = z % 10;
//     reverse = (reverse * 10) + digit;
//     z = parseInt(z / 10);
// }
// alert("reverse = " + reverse);


// function reverseNum(num) {
//     return (
//     Number(
//       num
//         .toString()
//         .split('')
//         .reverse()
//         .join('')
//     )
//   )
// }


// document.write(reverseNum(12345));
