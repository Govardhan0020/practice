

var arr=[
{name:"sree",age:24,gender:"female"},
{name:"Rama",age:21,gender:"male"},
{name:"srinath",age:23,gender:"male"},
{name:"Ganesh",age:25,gender:"male"}
];

var table =document.getElementById("tabledata");
function display() {
	var head='',body='';
	head="<table><tr><th>Name</th><th>Age</th><th>Gender</th></tr></table>";
	arr.forEach((item) =>
body += '<table>' +
        '<tr><td>'+ item.name+'</td>'+
        '<td>' + item.age +'</td>' +
        '<td>' + item.gender + '</td></tr>'
		)
	var result = head+body;
	table.innerHTML=result;
}

var locarr=[];
table.addEventListener('click',function setdata(name) { 
	var row = name.path[1];
	 
	var fname =row.cells[0].innerHTML; 
var arrindex = arr.findIndex((val) => val.name ==  fname)
console.log(arrindex);

var setname=arr[arrindex].name;
var setage=arr[arrindex].age;
var setgender = arr[arrindex].gender;

var locobj={Name:setname,Age:setage,Gender:setgender};
locarr.push(locobj);
localStorage.setItem("userdata", JSON.stringify(locarr));
// console.log(locarr);


}  )


function showdata() {
 var locdata = localStorage.getItem("userdata");
 var findata = JSON.parse(locdata);
 console.log(findata);
}
	


// function showdata() {
//  var locdata = localStorage.getItem("userdata");
//  var findata = JSON.parse(locdata);
//  console.log(findata);
// }
// showdata();
