 var data =["html","css","javascript"];

 for(let x in data){
 	document.getElementById("demo").innerHTML+="<input type='checkbox' /> "+data[x]+  " <br> ";

 }


function clk(){
    var x= document.getElementById("inp1").value;
    
document.getElementById("data").innerHTML=x;

}

//  // document.getElementById('demo').innerHTML="hello";

// for(i=0;i<4;i++){
//     document.write("<input type='text' /> <br> ");
//  document.getElementById('demo').innerHTML+="<input type='checkbox' /> <br> ";
// }



data = [
{
"id":1,
"name":"rama",
"lname":"sri",
"age":25, 

},

{
"id":2,
"name":"rama1",
"lname":"sri1",
"age":26,   
},
{
"id":3,
"name":"rama2",
"lname":"sri2",
"age":27,
},
{
"id":4,
"name":"rama3",
"lname":"sri3",
"age":28,
}

]

let jsdata = JSON.stringify(data);
document.write(jsdata);
 


 let data1 = '[{ "name":"rama", "age":30  },  { "name":"sita", "age":56 }] ';

 document.write(data1);
