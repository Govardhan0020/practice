var data =[
{
	"id":1,
	"name":"raju",
	"mail":"raju@gmailcom"

},
{
   "id":2,
   "name":"rama",
   "mail":"rama123@gmail.com"
},
{
	"id":3,
	"name":"sreeja",
	"mail":"sreeja@gmail.com"
}
];

 function searchd() {
 	let searchdata = document.getElementById("searchdata").value;
alert(searchdata);

 var filtered =data.filter((ele) => ele.name.includes("searchdata"));
 var res= filtered.map((ele) => (ele.name)  )
 document.getElementById('res').innerHTML = res +"<br>";

 }
