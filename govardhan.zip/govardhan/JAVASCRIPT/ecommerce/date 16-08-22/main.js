$(document).ready(function(e){

    jsonObject.products.forEach((i)=>loadProducts(i));

});


function loadProducts(data){

    var div = document.createElement('div');

    div.innerHTML =  '<div class="card m-1 bg-dark " >'+
    '<img src="'+data.image+'" class="rounded product-1 align-items-center p-2 text-center" width="150" height="130">'+
        '<h6 class="mt-1 font-weight-bold mb-2 text-white info">'+data.title+'</h6>'+
        '<p class="mt-3 info"> <span class="text1 d-block">'+ data.description+' </span> </p>'+
        '<p class=" cost mt-1 text-dark"> <span>Rs .'+data.price+'</span>'+
        '</p>'+
    '<button class="button-color p-2 text-center text-white"> <span class="text-uppercase ">Add to cart</span> </div>'+
'</button>'+
    '</div>';
document.getElementById("home_product").appendChild(div);
}
