	
function submithandeler() {

	let mail =document.getElementById('email').value;
	let password = document.getElementById("password").value;

 // if(password.length <=8){
 // 	alert("password is below 8 characters ");
 // }

 let uppercaseletters = /[a-z]/g ;
 let numbers = /[0-9]/g ;
 let lowerCaseLetters = /[a-z]/g;

   if( password.length != ' ') { 
   if((password.length <= 8 ) && (password.match(numbers)) && (password.match(uppercaseletters)) && (password.match(lowerCaseLetters)) ) {
 	alert("password is strong ");
 } 
  else {
 	alert("password is not strong or below 8 characters ")
 }
}else {
	alert("password is not entered ");
}


if(password.length ==' ' && mail.length == '' ) { 
	alert("enter the password and email properly ");
   }
else {
 	alert("email   :"+mail  +"\n password   :" +password  )
 }


 }




 function resethandeler() {
   	document.getElementById('email').value =' ';
	document.getElementById("password").value ='';
 }

function myFunction() {
  var x = document.getElementById("password");
  if (x.type === "password") {
    x.type = "text";
  } else {
    x.type = "password";
  }
}

