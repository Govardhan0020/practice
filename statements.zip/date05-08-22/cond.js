var marks = Number(prompt("enter the marks "));
document.write("<h3> your marks are :"+marks + "</h3>");

if(marks >=90){
	document.write("<h3>your Grade is A+ </h3>");
} else if(marks >=80  && marks<=90){
	document.write("<h3>your Grade is A  </h3>");
}  else if(marks >=70  && marks<=80){
	document.write("<h3>your Grade is B+ </h3>");
}   else if(marks >=60  && marks<=70){
	document.write("<h3>your Grade is B  </h3>");
}  else if(marks >=50  && marks<=60){
	document.write("<h3>your Grade is C </h3>");
}   else if(marks >=40  && marks<=50){
	// document.write("<h3>your Grade is D </h3>");
} else {
	document.write("<h3>your are  just passed ");
}

