function show() {
	let rstart =document.getElementById('rstart').value;
	let rend =document.getElementById("rend").value;

let cstart =document.getElementById("cstart").value;
let cend = document.getElementById("cend").value;


	for(let i=rstart;i<=rend;i++){

		for(let j=cstart;j<cend-i;j++) {

		document.getElementById("id1").innerHTML+="* ";
		}
		document.getElementById('id1').innerHTML+="<br> ";
	}
}