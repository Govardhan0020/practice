
let a=new XMLHttpRequest();
a.open("GET","https://fakestoreapi.com/products",true)
a.send()
a.onload=function(){
    let data=JSON.parse(a.responseText)
    console.log(data)

    for (item of data){

        let mn=`<div class="store-product"id="hor"><div class="logo"><div class="war"> <img src=${item.image}></div>
            <div class="logo-1">
        <p class="bom">${item.title.substring(0,12)}</p>
        <h3>&#8377;${item.price}<span class="beat"id="beat" ondbclick="mybd()"><i class="fa-solid fa-heart"></i></span></h3>
       <p class="ab"> &#128970;&#128970;&#128970;&#9734</p><br>
        <button type="button" class="btn">ADD CARD</button>
        <span class="luckey"id="moon"ondbclick="mybdlike()"><i class="fa-solid fa-thumbs-up"></i></span>
        <div class="like"></div>
        <div id="dislike"></div>
        </div>
        </div>
        </div>
        `
        document.getElementById("fav-1").style.display="none"
        
        document.getElementById('demo').innerHTML+=mn

        /////<<<<<<<<>>>> Products details<><><><><><><><><><><> /////

   let dom=document.querySelectorAll(".war");
   
   dom.forEach(function (bm,i){
    bm.addEventListener("click",function (){
            document.getElementById("demo").innerHTML=`
            
                
                    <div class="i-1"> <img src=${data[i].image}>
                    <div class="fox">
                    <button class="but" onclick="myclose()">X</button><br>
                    <span><span class="bino">Product Price </span>-&#8377; ${data[i].price}</span>
                    <p><span class="bino">Product Title </span>- ${data[i].title}<br></p>
                    <p> <span class="bino">Product Rating  </span>- ${data[i].rating.rate}</p>
                    <span class="fa fa-star checked"></span>
                    <span class="fa fa-star checked"></span>
                    <span class="fa fa-star checked"></span>
                    <span class="fa fa-star checked"></span><br>
           </div>
           
            ` 
            document.getElementById("fav-1").style.display="none"
           
       });
   });

//<<<<<<<<<      Add to Cart   >>>>>>>>>

   let ibm=document.querySelectorAll(".btn");
    ibm.forEach(function (v,i){
    v.addEventListener("click",(e)=>{
       
        document.getElementById("bom").innerHTML=document.querySelectorAll(".tot").length
    document.getElementById("new").innerHTML+=`

    <div class="tot">
   
    <h1 style="text-align:center;">${data[i].category}</h1>
    <div class="i-1"> <img src=${data[i].image}>
    <div class="babu">
    <div class="cap">${data[i].title}</div><br><br>
    <span class="jom">&#8377;${data[i].price}</span><br><br>
    <span class="gom"> ${data[i].rating.rate}</span><br><br>
    <span class="fa fa-star checked"></span>
    <span class="fa fa-star checked"></span>
    <span class="fa fa-star checked"></span>
    <span class="fa fa-star checked"></span><br><br>
    <span class="cat">${data[i].category}</span><br><br>
    <span class="des"><span style="color: black;font-size: 21px; text-decoration: underline;">Description:</span><br>${data[i].description}</span><br><br>
    <button type="button" class="butt"id="duck"onclick="mybtn()">Remove</button>
    <button onclick="myorder()"id="demo-2">Order Now</button>
   
    </div>
</div>

    `
    document.getElementById("img").style.display="none"
    // document.getElementById("new").style.display="block" 
    // document.getElementById("fav-1").style.display="none" 
   
    })
})

    }    
    
    //</></></> ADD Favourites  <><><><><><><><>

    document.getElementById("favv-1").innerHTML=`<h1 class="good">Wow Your Choice is very Nice 👌</h1>`
    let you=document.querySelectorAll(".beat");
    you.forEach(function (h,u){
    h.addEventListener("click",(e)=>{
     document.querySelectorAll(".beat")[u].style.color="red"
     
     document.getElementById("new").style.display="none" 
        // document.getElementById("jan").innerHTML=document.querySelectorAll(".tot").length
    document.getElementById("fav-1").innerHTML+=`
   
   <div class="oop"> 
    <div class="i-1"> <img src=${data[u].image}>
    <div class="jani">
    <div class="fav-iteam-1">${data[u].title}</div>
    <div class="fav-iteam-2">&#8377;${data[u].price}</div>
    <div class="fav-iteam-3">${data[u].category}</div>

    </div>
    </div>
    
    `
    document.getElementById("img").style.display="none"
    })
})


////<><><><>>> Remove favorates <><><><><<><>

let yu=document.querySelectorAll(".beat");
yu.forEach(function (i,o){
i.addEventListener("dblclick",(e)=>{
    //alert("hello")
 document.querySelectorAll(".beat")[o].style.color="blue"
//  document.querySelectorAll(".oop")[o].style.display="none";

// if(color="red"){
//     document.querySelectorAll(".oop")[o].style.display="none";
// }else if(color="blue"){
//     document.querySelectorAll(".beat")[o].style.display="none";
// }
   
//      document.getElementById("jan").innerHTML=document.querySelectorAll(".tot").length
// document.getElementById("fav-1")[i].innerHTML="Your not clicked heart Symbol...."

})
})

    // if(you !== 0){
    //     document.getElementById("fav-1").innerHTML= "Please Once Click Your Favourite Products";
    // }else{
    //    // document.getElementById("fav-1").style.display="none"

    // }

    //<><><><>  LIKE <<><><><><><>>

    let li=document.querySelectorAll(".luckey");
    li.forEach(function (l,i){
        l.addEventListener("click",()=>{
            document.querySelectorAll(".luckey")[i].style.color="green"
            const myTimeout = setTimeout( mybb, 1000);
            const myTimeou=setTimeout(myjob,4000);
        })
        function mybb(){
            document.querySelectorAll(".like")[i].innerHTML=`<div class="mhbd">Thank You for Supporting😍</div>`;
        }
        function myjob(){
            document.querySelectorAll(".like")[i].style.display="none"
            document.querySelectorAll(".luckey")[i].style.color="black"

        }
    })

    ///<><><><><>    Dislike <><><><><><>

    let nm=document.querySelectorAll(".luckey");
    nm.forEach(function (g,h){
        g.addEventListener("dblclick",()=>{
            document.querySelectorAll(".luckey")[h].style.color="blue"
            document.querySelector(".like").style.display="none"
            document.querySelectorAll(".luckey")[h].innerHTML=`<i class="fa-solid fa-thumbs-down"></i>`
        })
      function mybdlike(){
        document.getElementById("moon").innerHTML=`😢`
      }
    })
    
    }    

    // function myFunction() {
    //     var x = document.getElementById("snackbar");
    //     x.className = "show";
    //     setTimeout(function(){ x.className = x.className.replace("show", ""); }, 3000);
    //   }

 
//<>>>>>>><>><<><><> CART FUNCTION <><><><><><><>

function myfun(){
    alert("Happy Shopping...")
    document.getElementById("new").style.display="block"
    document.getElementById("demo").style.display="none"
    document.getElementById("fav-1").style.display="none"

      document.getElementById("img").innerHTML=`<div class="empty-cart"id="zebra"><img src="no.png"></div>`
}

///<<><><><><><> Remove Iteams  <>>>>>><>>><<><><>///

function mybtn(){
let cm=1;
    let f=document.querySelectorAll(".butt");
    f.forEach(function (k,i){
        k.addEventListener("click",(e)=>{
             cm--
             document.getElementById("bom").innerHTML=cm
            document.querySelectorAll(".tot")[i].style.display="none";
            
        })
    })
}
    //<><><><> Click flipkart Main Menu functionality <><><><><><><><>

function view(){
    document.getElementById("new").style.display="none"
    document.getElementById("demo").style.display="block"
}
        //<><><><><><<><><> Product functionality <><<><<>

function myorder(){
   
    document.getElementById("new").innerHTML=`<span class="ord">Your Order Successfully...</span><span class="emoji">&#128540;</span><br><br>
    <button onclick="back()"class="back">Back</button>`
    
}

function back(){
    document.getElementById("demo").style.display="block";
    
}
        //<>>>><><><> Favorate functionality <><><><<><<><> 

function myheart(){
    document.getElementById("fav-1").style.display="block"
    document.getElementById("demo").style.display="none"
    document.getElementById("beat").disabled="true"
 }
 function myclose(){
   location.reload()
   }
    function mydb(){
        if(document.querySelectorAll(".beat")[u].style.color="red"){
            document.querySelectorAll(".beat").innerHTML="okay";
        }else if(color="blue"){
           document.querySelectorAll(".oop")[o].style.display="none";
        }
      }

index=0;
slides()
function slides(){
    let r=document.querySelectorAll(".maimg");
    for(var i=0;i<r.length;i++){
        r[i].style.display="none"
    }
    index++;
    if(index > r.length){
        index=1
    }
    r[index-1].style.display="block";
    setTimeout(slides,2000)
}



///<><><><><><><>images Sliders<<><>><><><><><<><>


//let index=0
// slid(index)

// function slides(){
//     slides()
// }
// function slid(){  
//     let x=document.getElementsByClassName("maimg");
//     if(index > x.length){
//         index=1
//     }
//     if(index < 1){
//         index=x.length
//     }
//     for(var i=0;i<x.length;i++){
//         x[i].style.display="none"
//     }
//     x[index-1].style.display="block"
// }
// function mylike(){
    
  
   
 //}

