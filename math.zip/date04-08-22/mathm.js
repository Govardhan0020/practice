

function absmath() {
let	val = prompt("enter number in positive or negative");
	document.getElementById("id1").innerHTML="your entered value is :"+ val;
	document.getElementById('id2').innerHTML="absolute value of the number is :"+ Math.abs(val);
}

function ceilmath() {
	let val = prompt("enter number in decimals only");
	document.getElementById("id1").innerHTML="your entered value is :"+ val;
	document.getElementById('id2').innerHTML="ceil value of the number is :"+ Math.ceil(val);
}


function floormath() {
	let val = prompt("enter number in decimals only");
	document.getElementById("id1").innerHTML="your entered value is :"+ val;
	document.getElementById('id2').innerHTML="floor value of the number is :"+ Math.floor(val);
}

function roundmath() {
  let val = prompt("enter number in positive or negative");
	document.getElementById("id1").innerHTML="your entered value is :"+ val;
	document.getElementById('id2').innerHTML="Rounded value of the number is :"+ Math.round(val);
}

function sqrtmath() {
	let val = prompt("enter number to find square root ");
	document.getElementById("id1").innerHTML="your entered value is :"+ val;
	document.getElementById('id2').innerHTML="square root of the number is :"+ Math.sqrt(val);
}


function randommath() {
	let val = prompt("enter number to find random number ");
	document.getElementById("id1").innerHTML="your entered value is :"+ val;
	document.getElementById('id2').innerHTML="random value of the number is :"+ Math.random(val);
}


function logmath() {
	let val = prompt("enter number to find log value ");
	document.getElementById("id1").innerHTML="your entered value is :"+ val;
	document.getElementById('id2').innerHTML="log value of the number is :"+ Math.log(val);
}


function truncmath() {
	let val = prompt("enter number to trunc the number ");
	document.getElementById("id1").innerHTML="your entered value is :"+ val;
	document.getElementById('id2').innerHTML="trunc value of the number is :"+ Math.trunc(val);
}


function expomath() {
	let val = prompt("enter number to find exponential value ");
	document.getElementById("id1").innerHTML="your entered value is :"+ val;
	document.getElementById('id2').innerHTML="exponential value of the number is :"+ Math.exP(val);
}


function sinmath() {
	let val = prompt("enter number to find sin value ");
	document.getElementById("id1").innerHTML="your entered value is :"+ val;
	document.getElementById('id2').innerHTML="sin value of the number is :"+ Math.sin(val);
}


function cosmath() {
	let val = prompt("enter number to find cos value ");
	document.getElementById("id1").innerHTML="your entered value is :"+ val;
	document.getElementById('id2').innerHTML="cos value of the number is :"+ Math.cos(val);
}


function tanmath() {
	let val = prompt("enter number to find tan value  ");
	document.getElementById("id1").innerHTML="your entered value is :"+ val;
	document.getElementById('id2').innerHTML="tan value of the number is :"+ Math.tan(val);
}

function powmath() {
	let x = prompt("enter the number ");
	let y = prompt("enter the power value to the number ");
	document.getElementById("id1").innerHTML="your entered number : "+x;;
	document.getElementById("id2").innerHTML="you entered power to the number :"+y;
	document.getElementById("id3").innerHTML="powerof the number is :"+Math.pow(x,y);
}

var data=[];
function maxmath() {
	
	var count =prompt('enter no. of value to give as input');
	for(let i=0;i<count;i++){
let num =prompt('enter the number  '+(i+1));
data.push(num);
	}
	let input = data.map((number) =>  Number(number));
	document.getElementById("id1").innerHTML="your entered numbers are :"+data;
	document.getElementById("id2").innerHTML="max number is"+Math.max(input);
}