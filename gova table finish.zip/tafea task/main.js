

 function openform(){
   document.getElementById("formdisplay").style.display="block";
  document.getElementById('submitbtn').style.display="block";
   document.getElementById("updatebtn").style.display="none";
 } 
 function closeform(){
   document.getElementById("formdisplay").style.display="none";
 } 
 
 var fname;
 var table =document.getElementById("mytable");
 
 var arr=[   { fname:"sree",lname:"sure",phone:9876576432,p_email:"sree123@gmail.com",s_email:"sree45@gmail.com",p_name:"amaxon",P_status:"running"},
   {fname:"nidhi",lname:"kalyani",phone:9874326789,p_email:"nidhi56@gmail.com",s_email:"niddhi34@gmail.com",p_name:"flipkart",P_status:"complated"},
   {fname:"rama",lname:"ponde",phone:9832786543,p_email:"rama67@gmail.com",s_email:"rama45@gmail.com",p_name:"myntra",P_status:"running"},
   {fname:"krishna",lname:"gayam",phone:9899765434,p_email:"krishna23@gmail.com",s_email:"krishna5@gmail.com",p_name:"bookmyshow",P_status:"completed"}
 ]

var count=1;
var result='',body='';
function createtable(){

  table.innerHTML=''
   result = '<thead><tr id="mytablestyle"><th>S.no</th><th>Name</th><th>Lastname</th><th>phonenumber</th><th>primary email</th>'+
    '<th>Secondary email</th><th>Project Name</th><th>Project Status </th><th colspan="3"><button id="addicon" onclick="openform()"><i class="fa fa-plus" ></i></button></th>'
    +'</tr></thead> ';
    
    arr.forEach( (data,i) => 
   body +=  '<tbody><tr id= " + i + ">' +
    '<td>'+ count++ + '</td>' + 
    '<td>'+ data.fname +'</td>' +
   '<td>' + data.lname +'</td>' +
   '<td>' + data.phone +'</td>'+
   '<td>' + data.p_email +'</td>'+
   '<td>' + data.s_email +'</td>'+ 
   '<td>' + data.p_name +'</td>'+
   '<td>' + data.P_status +'</td>' +
    '<td><input type="checkbox" id="checked" /></td><td><i onclick="deleteonerow( \''+data.p_email+'\')" class="fa fa-trash-o" style="font-size:20px;padding:2px 4px;"></i></td><td> <i onclick="editrow(\''+data.p_email+'\')" class="fa fa-pencil" style="padding:0px 4px;"></i> </td></tr></tbody>'
    )
 table.innerHTML =result+body;
}


var obj={};
 function validate() {
event.preventDefault();

var name =document.getElementById("name").value; 
var Lname =document.getElementById("lname").value; 
var p_num =document.getElementById("phonenumber").value; 
 var priemail =document.getElementById("pemail").value; 
var semail =document.getElementById("semail").value; 
var projectname =document.getElementById("pname").value; 
var projecttstatus =document.getElementById("pstatus").value; 

if( name == "" ) {
  alert("enter the name  ");
} else if(Lname ==  "") {
  alert("enter the last name  ");
} else if (p_num == ""  ){
  alert("enter the phone number properly ");
} else if(priemail == ""  ){
  alert("primary email must not empty ");
}else if(semail == ""  ){
  alert("secondary  email must not empty ");
} else if(priemail == semail){
  alert("primary mail and secondary mail must not same ");
} else if(arr.find(val =>  val.p_email == priemail)){
  alert("The primary email is already exist on another contact \n please enter another primary email ");
} else if(arr.find(val => val.s_email == semail)){
alert("The Secondary email is already exists on another contact \n please enter another secondary email ");
}else if(projectname ==""){
  alert("project name must not empty");
}else if(projecttstatus == ""){
  alert("project status must not empty")
}else {  
obj={ 
    fname:name,
    lname:Lname,
     phone: p_num,
    p_email:priemail,
     s_email:semail,
  p_name: projectname,
  P_status:projecttstatus
}

arr.push(obj);
alert("data is  successfully submitted");
document.getElementById("formdisplay").style.display="none";
table.innerHTML='';
createtable();
}
console.log(arr);
 }

 
function searchdata() {
  
  var input, filter, table, tr, td, i;
  input = document.getElementById("myInput");
  filter = input.value.toUpperCase();
  table = document.getElementById("mytable");
  tr = table.getElementsByTagName("tr");
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[1];
    if (td) {
      if (td.innerHTML.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    }       
  }
}
 

// var k;
//function deleteonerow(email) {

//   for(k in arr){
//     if(arr[k].p_email == email){
//       arr.splice(k,1);
//     //  console.log(arr);
//       // console.log(email);
//     }
//   }
// table.innerHTML='';
//    createtable();
// }



 function deleteonerow()  {
    let checkbox =document.getElementById('checkbox');
   let box =document.getElementById('+ i + ' );
   if( box.checked == true){
   checkbox.style.display="none";
     }
}


function editrow(email) {
document.getElementById("submitbtn").style.display="none";
 document.getElementById("updatebtn").style.display="block";
for(var k in arr){
    if(arr[k].p_email == email){
     // arr.splice(k,1);
document.getElementById("formdisplay").style.display="block";
console.log(arr[k],"array of k ")
   document.getElementById("name").value =arr[k].fname;
  document.getElementById("lname").value =arr[k].lname; 
 document.getElementById("phonenumber").value =arr[k].phone; 
 document.getElementById("pemail").value = arr[k].p_email; 
 document.getElementById("semail").value = arr[k].s_email; 
 document.getElementById("pname").value = arr[k].p_name; 
 document.getElementById("pstatus").value = arr[k].P_status; 
  console.log(arr);
  console.log(email);
    }
  }
}


let getpemail = document.getElementById("pemail");
function updatedata(){
  event.preventDefault();
  //alert("hi");
  let mail=getpemail.value;
for(let br of arr){

  if(br.p_email == mail){
  // alert("hi");
   // console.log(br,"br email");
  br.fname=document.getElementById("name").value;
  br.lname=document.getElementById("lname").value;
  br.phone=document.getElementById("phonenumber").value;
  br.p_email=document.getElementById("pemail").value;
  br.s_email=document.getElementById("semail").value;
  br.p_name=document.getElementById("pname").value;
  br.P_status=document.getElementById("pstatus").value;
  }    
}
 document.getElementById("formdisplay").style.display="none";
table.innerHTML='';
createtable();
}

