var string,start,end,count;
function strval() { 
string = prompt("enter the string :");
}

function len() {
	
	let result = string.length;

	document.getElementById('string').innerHTML ="entered  string  is : "+  string;
	document.getElementById('result').innerHTML ="length of string  is : "+  result;

document.getElementById('start').innerHTML =" ";
  document.getElementById('end').innerHTML =" ";
document.getElementById('count').innerHTML =" ";
}

function strslice() {
	start =prompt("enter starting position");
	end = prompt("enter the ending position");
let result = string.slice(start,end);

document.getElementById('string').innerHTML ="entered  string  is : "+  string;
	document.getElementById('result').innerHTML =" sliced string is : "+ result;
document.getElementById('start').innerHTML ="started from  : "+  start;
	document.getElementById('end').innerHTML ="ends to : "+ end;
document.getElementById('count').innerHTML =" ";
}

function strsubstring() {
    start =prompt("enter starting position");
	end = prompt("enter the ending position");

let result =  string.substring(start,end);

document.getElementById('string').innerHTML ="entered  string  is :"+  string;
	document.getElementById('result').innerHTML =" substring is : "+ result;
document.getElementById('start').innerHTML ="started from  : "+  start;
	document.getElementById('end').innerHTML ="ends to : "+ end;
document.getElementById('count').innerHTML =" ";
}

function strsubstr() {
	 start =prompt("enter starting position");
	count= prompt("enter the count of letters");

let result =  string.substr(start,end);

document.getElementById('string').innerHTML ="entered  string  is : "+  string;
	document.getElementById('result').innerHTML =" substr is : "+ result;
document.getElementById('start').innerHTML ="started from  : "+  start;
	document.getElementById('count').innerHTML ="count of letters  : "+ count;
document.getElementById('count').innerHTML =" ";
}

function strreplace() {
	let rep1 =prompt("enter the presented data to replace");
	let rep2 = prompt("enter the replacing data ");

	let result = string.replace(rep1,rep2)

document.getElementById('string').innerHTML ="entered  string  is= "+  string;
	document.getElementById('result').innerHTML ="  replaced string is : "+ result;
document.getElementById('start').innerHTML ="prsented data to replace : "+  rep1;
	document.getElementById('end').innerHTML ="replacing data  : "+ rep2;
document.getElementById('count').innerHTML =" ";
}

function strupper() {

	let result = string.toUpperCase();

	document.getElementById('string').innerHTML ="entered  string  is : "+  string;
	document.getElementById('result').innerHTML ="UpperCase string is : "+  result;

document.getElementById('start').innerHTML =" ";
  document.getElementById('end').innerHTML =" ";
document.getElementById('count').innerHTML =" ";
}

function strlower() {

	let result = string.toLowerCase();

	document.getElementById('string').innerHTML ="entered  string  is : "+  string;
	document.getElementById('result').innerHTML ="LowerCase string is : "+  result;

document.getElementById('start').innerHTML =" ";
  document.getElementById('end').innerHTML =" ";
document.getElementById('count').innerHTML =" ";

}

function strcharat() {
	let x = prompt("enter value(number) to find which letter at that place ");
	let result =string.charAt(x+1);

	document.getElementById('string').innerHTML ="entered  string  is : "+  string;
	document.getElementById('result').innerHTML ="charAt the place is : "+  result;
  document.getElementById('start').innerHTML ="you entered value : "+  x;
  document.getElementById('end').innerHTML =" ";
document.getElementById('count').innerHTML =" ";
}

function strcharcodeat() {
	let x = prompt("enter value(number) to find its ASCII code  ");
	let result =string.charAt(x+1);

	document.getElementById('string').innerHTML ="entered  string  is : "+  string;
	document.getElementById('result').innerHTML ="charCodeAt of the string is  : "+  result;
  document.getElementById('start').innerHTML ="you entered value : "+  x;
  document.getElementById('end').innerHTML =" ";
document.getElementById('count').innerHTML =" ";
}

function strsplit() {
start = prompt("enter the any character to split ");
let result = string.split(start);

	document.getElementById('string').innerHTML ="entered  string  is : "+  string;
	document.getElementById('result').innerHTML ="splited string is : "+  result;

document.getElementById('start').innerHTML =" your entered character is :"+start ;
  document.getElementById('end').innerHTML =" ";
document.getElementById('count').innerHTML =" ";
}

function strfromcharcode() {

	start = prompt("enter the ASCII code to convert it into character ");
	let result =  String.fromCharCode(start);
document.getElementById('string').innerHTML ="entered  string  is : "+  string;
	document.getElementById('result').innerHTML ="charcode to  string  converted value is :"+  result;
	document.getElementById('start').innerHTML ="you entered value is :"+  start;
  document.getElementById('end').innerHTML =" ";
document.getElementById('count').innerHTML =" ";
}

function strtrim() {

let result = string.trim();

document.getElementById('string').innerHTML ="entered  string  is : "+  string;
	document.getElementById('result').innerHTML ="Trimmed string is : "+  result;

document.getElementById('start').innerHTML =" ";
  document.getElementById('end').innerHTML =" ";
document.getElementById('count').innerHTML =" ";

}

function strsearch() {
 start = prompt("enter the searching value ");
let result = string.search(start);

document.getElementById('string').innerHTML ="entered  string  is : "+  string;
	document.getElementById('result').innerHTML ="searched string is : "+  result;

document.getElementById('start').innerHTML ="your searched value is : "+ start;
  document.getElementById('end').innerHTML =" ";
document.getElementById('count').innerHTML =" ";

}

function strmatch() {

	start = prompt("enter the matching value");
 
let result = string.match(start);

document.getElementById('string').innerHTML ="entered  string  is : "+  string;
	document.getElementById('result').innerHTML ="matched string is : "+  result;

document.getElementById('start').innerHTML ="your searched value is : "+ start;
  document.getElementById('end').innerHTML =" ";
document.getElementById('count').innerHTML =" ";

}

function strindexof() {
	start = prompt("entr the string to find the index ");
 
let result = string.indexOf(start);

document.getElementById('string').innerHTML ="entered  string  is : "+  string;
	document.getElementById('result').innerHTML ="IndexOf the string is : "+  result;

document.getElementById('start').innerHTML ="your searched value is : "+ start;
  document.getElementById('end').innerHTML =" ";
document.getElementById('count').innerHTML =" ";

}

function strlastindexof() { 

start = prompt("entr the string to find the index ");
 
let result = string.lastIndexOf(start);

document.getElementById('string').innerHTML ="entered  string  is : "+  string;
	document.getElementById('result').innerHTML =" lastindexOf the string is : "+  result;

document.getElementById('start').innerHTML ="your searched value is : "+ start;
  document.getElementById('end').innerHTML =" ";
document.getElementById('count').innerHTML =" ";

}


function strIncludes() {

start = prompt("entr the string to find is it present or not  ");
 
let result = string.includes(start);

document.getElementById('string').innerHTML ="entered  string  is : "+  string;
	document.getElementById('result').innerHTML =" Result is  : "+  result;

document.getElementById('start').innerHTML ="your searched value is : "+ start;
  document.getElementById('end').innerHTML =" ";
document.getElementById('count').innerHTML =" ";

}	

function strconcat() {
	let str1 = prompt("enter first string  to concat");
	let str2 = prompt("enter second string to concat ");
	let result = str1.concat(str2);

document.getElementById('string').innerHTML =" ";
	document.getElementById('result').innerHTML =" Result is  : "+  result;

document.getElementById('start').innerHTML ="your entered first string is  : "+ str1;
  document.getElementById('end').innerHTML ="your entered second string is  : "+ str2;
document.getElementById('count').innerHTML =" ";

}	





