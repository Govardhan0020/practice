document.write("hello");
console.log("hello govardhan");


document.write("<br>")
let a=Number(prompt("enter first number" ));
let b=Number(prompt("enter second number" ));
let c= a+b;
document.write("<h1> c is =" +c  +"</h1>")

 function full() { 

function fun1() {
let x =document.getElementById('one')
 
x.style.color="white";
x.style.backgroundColor="blue";
x.style.textAlign ="center";
}
fun1();
function fun2() {
	let y = document.getElementById("two")
	y.style.color="white";
y.style.backgroundColor="red";
y.style.textAlign="center";
// y.style.display='none';
}
fun2();
 }



	function f1() {
		document.write("<br>");
		document.write("i am function 1");
		setTimeout(f2,2000);
	}

		function f2 () {
		document.write("<br>");
				document.write("i am function 2");
		setTimeout(f1,2000);
	}

function add() {
	let n1 = document.getElementById("num1").value ;
	let n2 = document.getElementById("num2").value;
	let res = Number(n1) + Number(n2) ;
	document.getElementById("result").innerHTML = res;
}

