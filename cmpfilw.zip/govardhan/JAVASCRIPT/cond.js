let a= prompt("enter your first number ");
//  let b = prompt("enter your second number ");

if(a>=75 && a<=99){
	document.write("<h3> distinsion A+ grade </h3> <br> ");
}
else if(a>=60 && a<=75) {
	document.write(" <h3> you got  A grade </h3>  <br> ");
	}
else if(a>=50 && a<= 60 ){
document.write(" <h3> you got B+ grade </h3> ");
}
else if(a>=35 && a<=50 ) {
	document.write(" <h3> you got B grade </h3> ");
}
else {
	document.write("<h3> Invalid  Input </h3> ")
}


/* ARRAY METHOD PRACTISE */  

let arr =["goa", "rama ", "hello" ,6,9,7,"hem" ];

let res = arr.sort()
document.write(" <h2> Result is = " + res + "</h2>")

let constr = arr.toString();
document.write("<h3>toString = " + constr +"</h3> ") ;

document.write("<h3> indexof = "+ arr.indexOf("hem"));

document.write("<h3> includes  = "+ arr.includes("hem"));

document.write("<h3> Join  = "+ arr.join(" / "));


 let str = "hello world! some other friends are their in our world ";
document.write("<br>");
document.write(" padstart =" +str.padStart(4,"a"));
let string = "h";
let pad = string.padStart(4,"*");
document.write("<br>")
document.write("padding ="+pad + "<br> ");
document.write("padend ="+string.padEnd(5,"*") + "<br>");
document.write("charat =" + str.charAt(6) + "<br> ");

document.write("search = " + str.search("are") + "<br> ");
document.write("search = " + str.match(/rld/g) + "<br> ");
