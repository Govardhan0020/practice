var data = [];
var count;

function inputdata() {  
 count  = prompt("enter no. of values to store in array");
for(var i=0; i<count; i++)  {
	var val = prompt("enter values "+ (i+1));
    data.push(val);
}

for(let j=0;j<count;j++) { 
document.getElementById('outputdata').innerHTML +=data[j] +"<br>"; 

}
}

function search(searchdata) {
	searchdata = prompt("enter some data to find ");

	if(data.indexOf(searchdata) !== -1 ) {
		
		document.getElementById("Res").innerHTML= "data found  ";
	    	document.getElementById("index").innerHTML="location at : "+(data.indexOf(searchdata)+1) ;
        	 document.getElementById('find').innerHTML="you searched data is :" + searchdata;
			}
      else {
      	 document.getElementById('Res').innerHTML = " Data not found";
      	  document.getElementById('find').innerHTML="you searched data is :" + searchdata;      	
      }
}


