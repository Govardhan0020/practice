
// function finding(arg1,arg2) {
	 
// 	if(arg1.indexOf(arg2) !== -1 && arg1.length <= arg1.length+1){
// 		document.write("<h3>"+ arg2," ", arg1.indexOf(arg2) +"</h3>");
// 	}
// else {
// 	document.write("<h3> not data found! </h3> ");
// }
// }

// var count = prompt("enter no. of value");
// var x;
// for(var i=0;i<count;i++){
// 	 x= prompt( "enter value to display  "+ (i+1) );

// 	document.write("<h4>", x ,"</h4>");
	
// }
//  var  arg2val =prompt("enter some date to  find ");
// document.write("<h3> your finding data =  ", arg2val,"</h3>" );


// // const arg1val = [" hello","sree","gopal","remesh", "raja"];
// // finding(["sreehello","govardhan","gova","goa","textbook",20],20)

// finding(x,arg2val);


// let fun =() => {
// 	console.log("hello world!");
// }
// fun();

// const arr =[
// {
// 	"id":1,
// 	"name":"hello"
// },
// {
// 	"id":2,
// 	"name":"rama"
// },
// {
// 	"id":3,
// 	"name":"sita"
// },
// {
// 	"id":4,
// 	"name":"ganesha"
// }

// ];


// // const filtering = arr.filter((item) =>item.name.incluees("sita")  )
// // document.write(filtering.map(() => item.name))

// document.write( arr.map((item) => "<div> "+ (item.id)+ " "+ (item.name) +"</div>"   ) );



// var count = prompt("enter no. of values to store in array")
// var data = [];
// for(var i=0; i<count; i++)  {
// 	var val = prompt("enter values")
//     data.push(val);
// }

// for(let j=0;j<count;j++) {
// 	document.write(data[j])
// }
//  document.write("<h2>", data ,"</h2>");

//   console.log(data);

 const arr1 = [34,77,"heoo","sree"];
 arr1.push("goa");
 document.write(arr1, "<br>");
 arr1.unshift("hero");
document.write(arr1,"<br>");

arr1.pop();
document.write(arr1,"<br>");

arr1.shift();
document.write(arr1,"<br>");

arr1.slice(1);
document.write(arr1,"<br>");
arr1.splice(0,1);
document.write(arr1,"<br>");
let len = arr1.length;
document.write(len,"<br>");

arr1.reverse();
document.write(arr1,"<br>");

var arr2=[34,56,67,78,"hello"];
var c= ["hello","gova","rama"];
 var final = arr2.concat(c);
document.write(final);
document.write(final.sort());
document.write(final.join("*"), "<br> ")
document.write("<br>");

// STRING FUNCTIONS 


let str= "Rama    Krishna     oaranahamsha ";

document.write(str, "<br>");
document.write(str.length, "<br>");
document.write(str.slice(3,18), "<br>");
document.write(str.substring(5,20), "<br>");
document.write(str.substr(2,15), "<br>");

document.write(str.replace("Rama","PAMA") , "<br>");
document.write(str.trim(), "<br>");
document.write(str.toUpperCase(), "<br>");
document.write(str.toLowerCase(), "<br>");
document.write(str.charAt(8), "<br>");
document.write(str.charCodeAt(20), "<br>");
document.write(str.split(" "), "<br>");
document.write(str.indexOf("Rama"), "<br>");
document.write(str.lastIndexOf("Krishna"), "<br>");
document.write(str.includes("Rama"), "<br>");
document.write(str.search("Rama"), "<br>");









